#!/bin/bash
cat stub.sh jolinar-2.jar > ./jolinar && chmod +x ./jolinar